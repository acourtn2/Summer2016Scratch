import java.util.*;
public class Comparer {
	private TableInfo holder;
	private Date now;
	
	public Comparer(){
		
	}
	
	
	public void compare(int code, ArrayList<ArrayList<RowInfo>> tableOne, ArrayList<ArrayList<RowInfo>> tableTwo){
		// code 1: only changes from unavailable/non-existant to open
		// code 2: changes from non-existant to open
		// code 3: all changes
		now = new Date();
		now.setTime(0);
		if(code == 1){
			compare1(tableOne, tableTwo);
		} else if( code == 2){
			
		} else if (code == 3){
			
		} else {
			System.out.println("Compare error, defualt used");
			
		}
		
	}
	
	private void compare1(ArrayList<ArrayList<RowInfo>> tableOne, ArrayList<ArrayList<RowInfo>> tableTwo){
		for(int i = 1; i < tableOne.size(); i++){ // skips i = 0, as is a base holder;
			for(int j = 0; j < tableOne.get(i).size(); j++){
				if(now.compareTo(tableOne.get(i).get(0).getDate()) <= 0){
				
					holder.addRowInfo(tableOne.get(i).get(j));
				}
			}
		}
		for(int i = 1; i < tableTwo.size(); i++){
			for(int j = 0; j < tableTwo.get(i).size(); j++){
				if(now.compareTo(tableTwo.get(i).get(0).getDate()) <= 0){
					RowInfo temp = tableTwo.get(i).get(j);
					
					int dateIndex = holder.getDateIndex(temp.getDate());
					if(dateIndex == -1){
						holder.addRowInfo(temp);
						//added shift with new date
					} else {
						ArrayList<RowInfo> section = holder.getDates().get(dateIndex);
						boolean found = false;
						for(int k = 0; k < section.size(); k++){
							if(section.get(k).isSame(temp)){
								section.remove(k);
								if(section.size() == 0){
									holder.getDates().remove(dateIndex);		
								}
								found = true;
								break;
							}
						}
						if(!found){
							holder.addRowInfo(temp);// existing Date,added shift
						}
					}
				}
			}
		}
		holder.printTable();
		
		
	}
	
	private void compare2(ArrayList<ArrayList<RowInfo>> tableOne, ArrayList<ArrayList<RowInfo>> tableTwo){
		
	
	}
	
	private void compare3(ArrayList<ArrayList<RowInfo>> tableOne, ArrayList<ArrayList<RowInfo>> tableTwo){
		
		
	}
}
