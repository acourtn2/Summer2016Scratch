import java.util.*;
import java.io.*;
public class Paster {
    private FileWriter fw;
    
	public Paster(){
		
	}

	public void makeFile(String fileName, ArrayList<ArrayList<RowInfo>> inRI){
		try{       
	            fw = new FileWriter(fileName + "Refined" + ".txt");
	            for(int i = 0; i < inRI.size(); i++){
	            	for(int j = 0; j < inRI.get(i).size(); j++){
	            		RowInfo holder = inRI.get(i).get(j);
	            		fw.write(holder.getDate() + "/" + holder.getWho() + "/" + holder.getTakenBy()+ "/" + holder.getTime() + "|");
	            		fw.flush();
	            	}
	            }
	            fw.write("||");
	            fw.flush();
	           
	            fw.close();
	            
	    } catch (FileNotFoundException fnf){
	       	fnf.printStackTrace();
	    } catch (IOException ioe) {
	        ioe.printStackTrace();
	    } finally {  	
	    }
	}
	
}
