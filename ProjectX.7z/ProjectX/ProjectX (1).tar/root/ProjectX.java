import java.util.Date;
@SuppressWarnings("deprecation")
public class ProjectX{
    public static void main(String[] args){
        Puller c = new Puller();
        c.makeFile();
        
        Parser b = new Parser(c.getFilName());
        b.parse();
        b.getTableInfo().printTable();
      /*
        TableInfo a = new TableInfo();
        RowInfo d = new RowInfo(new Date(114,5,14) , "d", "d",1);
        RowInfo e = new RowInfo(new Date(116,5,3) , "e", "e",7);
        RowInfo f = new RowInfo(new Date(116,5,5) , "f", "f",1);
        RowInfo g = new RowInfo(new Date(116,5,3) , "g", "g",20);
        RowInfo j = new RowInfo(new Date(116,5,3) , "j", "j",3);
        RowInfo k = new RowInfo(new Date(116,5,3) , "g", "g",3);
        RowInfo h = new RowInfo(new Date(116,5,4) , "h", "h",1);
        RowInfo i = new RowInfo(new Date(116,4,17) , "i", "i",1);
        a.printTable();
        System.out.println("--------------------------");
        a.addRowInfo(d);
        a.addRowInfo(e);
        a.addRowInfo(f);
        a.addRowInfo(g);
        a.addRowInfo(h);
        a.addRowInfo(i);
        a.addRowInfo(j);
        a.addRowInfo(k);
        a.printTable();
        */
    }
}