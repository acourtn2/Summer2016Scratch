import java.io.*;
import java.util.Date;
public class Parser{
    private String PRECURSE = " <tr><th>Subbing Out</th><th>Date</th><th>Time</th><th>Taken By</th></tr>";
    private File inFile;
    private InputStream is;
    private BufferedReader br;
    private String temp;
    private FileWriter fw;
    private Date cur;
    
    public Parser(Date cur){
        this.cur = cur;
        
    }
    
    public void parse(){
        try{
           
            br = new BufferedReader(new FileReader("TestFile" + cur + ".txt"));
           
            temp =br.readLine();
            while(temp != null || temp != PRECURSE){
                temp = br.readLine();
                
            }
            if(temp == null){
                System.out.println("Error, no precurser found");
            } else if (temp == PRECURSE){
                System.out.println("Righto");
                
                
                
            } else {
                System.out.println("Error while reading file");
            } 
        } catch (IOException ioe){
            System.out.println("IEOXCEPTION THROWN");
        }
        
        
        
    }
}