#include <iostream>
#include "LList.h"
using namespace std;

int main()
{
   cout << "Hello World" << endl; 
   LList a = new LList(7);
   LList b = new LList(4,*a);
   delete a;
   delete b;
   return 0;
}

