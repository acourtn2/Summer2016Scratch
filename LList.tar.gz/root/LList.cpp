#include "LList.h"
#include <cstdio>

LList::~LList(){
    if(next != NULL){
        delete next;
        
    }
        value = NULL;

}

LList::LList(){
    value = -1;
    next = NULL;
    
}

LList::LList(int a){
    value = a;
    next = NULL;
    
}

LList::LList(int a, LList* ptr){
    value = a;
    next = ptr;
    
}

void LList::add(LList* n){
    if(next = NULL){
        next = n;
        
    }
    
}