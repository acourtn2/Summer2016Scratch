

class LList{
    public:
        LList();
        LList(int a);
        LList(int a, LList* ptr);
        ~LList();
        void add(LList* n);
    private:
        int value;
        LList* next;
    
};