import java.util.Date;

public class RowInfo{
    private Date d;
    private boolean foundChanged;
    private String who, takenBy;
    private int time;
    
    public RowInfo(Date d, String who, String takenBy, int time){
        this.d = d;
        this.who = who;
        this.takenBy = takenBy;
        this.time = time;
    }
    public RowInfo(RowInfo cop){
        this.d = cop.getDate();
        this.who = cop.getWho();
        this.takenBy = cop.getTakenBy();
        this.time = cop.getTime();
        
    }
    public int getTime(){
        return this.time;
    }
    public Date getDate(){
        return this.d;
    }
    public String getWho(){
        return this.who;
    }
    public String getTakenBy(){
        return this.takenBy;
    }
    public boolean ifFoundChanged(){
        return this.foundChanged;
    }
    public String toString(){
        return ("Date: " + this.getDate() + "\nWho: " + this.getWho() + "\nTakenBy: " + this.getTakenBy() + "\nTime: " + this.getTime());
    }
}