import java.net.*;
import java.io.*;
import java.util.Date;
public class Puller{
    private URL url;
    private InputStream is;
    private BufferedReader br;
    private String temp, filName;
    private FileWriter fw;
    private Date cur;
    public Puller(){
        
        
    }
    public Date getCurDate(){
        return cur;
        
    }
    public String getFilName(){
    	return this.filName;
    }
    public void makeFile(){
        try{
            url = new URL("http://quest.library.illinois.edu/timesheet/publicsub.asp");
            is = url.openStream();
            br = new BufferedReader(new InputStreamReader(is));
            cur = new Date();
            filName = cur.toString();
            while(filName.contains(" ")){
            	filName = filName.substring(0, filName.indexOf(" ")).concat(filName.substring(filName.indexOf(" ") +1));
            }
            while(filName.contains(":")){
            	filName = filName.substring(0, filName.indexOf(":")).concat(filName.substring(filName.indexOf(":") +1));
            }
            fw = new FileWriter("TestFile" + filName + ".txt");
            temp = br.readLine();
            
            while(temp!= null){
                fw.write(temp + "\n");
                temp = br.readLine();
                fw.flush();
            }
            fw.close();
            
        } catch (MalformedURLException mue) {
             mue.printStackTrace();
        } catch (FileNotFoundException fnf){
        	fnf.printStackTrace();
        } catch (IOException ioe) {
            ioe.printStackTrace();
        
        } finally {
        	try {
        		if (is != null) is.close();
        	} catch (IOException ioe) {
        		// nothing to see here
        	}
        }
}
        
    
    
}