import java.io.*;
import java.util.Date;
public class Parser{
    private String PRECURSE =  " <tr><th>Subbing Out</th><th>Date</th><th>Time</th><th>Taken By</th></tr>";
    private File inFile;
    private InputStream is;
    private BufferedReader br;
    private String temp, holder, filName;
    private FileWriter fw;
    private FileReader fr;
    
    public Parser(String filName){
        this.filName = filName;
        
    }
    
    public void parse(){
        try{
            fr = new FileReader("TestFile" + this.filName + ".txt");
            br = new BufferedReader(fr);
           
            temp =br.readLine();
            while(temp != null && !(temp.equals(PRECURSE))){
                System.out.println(temp);
                temp = br.readLine();
                
            }
            if(temp == null){
                System.out.println("Error, no precurser found");
            } else if (temp.equals(PRECURSE)){
                System.out.println("Righto");
                holder = br.readLine();
                System.out.println(holder);
                System.out.println("---------------------------------------------");
                makeTable(holder);
                
            } else {
                System.out.println("Error while reading file");
            } 
        } catch (FileNotFoundException fnf){
            System.out.println("FILENOTFOUND THROWN");
        } catch (IOException ioe){
            System.out.println("IEOXCEPTION THROWN");
        } finally {
            try {
                if(is != null){ is.close();}
            } catch (IOException ioe){
                
            }
        }
        
        
        
    }
    
    @SuppressWarnings("deprecation")
	public void makeTable(String base){
    	String baseline = base;
    	String whoTemp,takenByTemp,section;
    	int timeTemp;
    	Date dTemp;
    	//while(baseline.length() > 1){
    		section = baseline.substring(0,(baseline.indexOf("</tr>")+5));
    		baseline = baseline.substring(baseline.indexOf("</tr>")+5);
    		System.out.println("Section: " + section);
    		//System.out.println(baseline);
    		
    		
    		if(section.substring(0,15).contains("<b>")){
    			whoTemp = section.substring(11,section.indexOf("</b>"));

    		} else {
    			whoTemp = section.substring(8, section.indexOf("</td>"));

    			//System.out.println(whoTemp);
    		}
    		System.out.println("WhoTemp: " + whoTemp);
    		section = section.substring(section.indexOf("</td>")+5);
    		System.out.println("Section: " +section);
    	//	System.out.println(Integer.valueOf(section.substring(17,21)));
    		//System.out.println(Integer.valueOf(section.substring(14,16)));
    		//System.out.println(Integer.valueOf(section.substring(12,13)));
    		dTemp = new Date(Integer.valueOf(section.substring(17,21)) - 1900, 
    						 Integer.valueOf(section.substring(12,13))-1,
    						 Integer.valueOf(section.substring(14,16)));
    		System.out.println("DTemp: " + dTemp);
    		section = section.substring(44);
    		System.out.println("Section: " +section);
    		
    		String timeTempS = section.substring(section.indexOf(">")+1,section.indexOf("</td>"));
    		System.out.println("TimeTempS: " + timeTempS);
    		timeTemp = Integer.valueOf(timeTempS.substring(0,timeTempS.indexOf("M")-1));
    		if(timeTempS.contains("PM")){
    		    if(timeTemp != 12){
    		        timeTemp = timeTemp + 12;
    		    }
    		} else if (timeTempS.contains("AM")){
    		    if(timeTemp == 12){
    		        timeTemp = 0;
    		    }
    		    
    		} else { //bug case
    		    timeTemp = 25;
    		} 
    		if(timeTemp == 25){
    		    System.out.println("ERROR, TIME TEMP IS INCORRECT");
    		}
    		section = section.substring(section.indexOf("</td>")+5);
    		System.out.println("TimeTemp: " + timeTemp);
    		System.out.println("Section: " +section);
    		
    		takenByTemp = section.substring(section.indexOf(">")+1, section.indexOf("</td>"));
    		System.out.println("TakenbyTemp: " + takenByTemp);
    		
    		
    		
    		
    	//}
    }
    
    public boolean same(RowInfo a, RowInfo b){
        if((a.getDate() == b.getDate()) && (a.getTakenBy() == b.getTakenBy()) && (a.getWho() == b.getWho()) && (a.ifFoundChanged() == b.ifFoundChanged())){ 
            return true;
        } else {
            return false;
        }
    }
}