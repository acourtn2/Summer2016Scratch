import java.io.*;
import java.util.Date;
public class Parser{
    private String PRECURSE =  " <tr><th>Subbing Out</th><th>Date</th><th>Time</th><th>Taken By</th></tr>";
    private File inFile;
    private InputStream is;
    private BufferedReader br;
    private String temp, holder;
    private FileWriter fw;
    private Date cur;
    private FileReader fr;
    
    public Parser(Date cur){
        this.cur = cur;
        
    }
    
    public void parse(){
        try{
            fr = new FileReader("TestFile" + this.cur + ".txt");
            br = new BufferedReader(fr);
           
            temp =br.readLine();
            while(temp != null && !(temp.equals(PRECURSE))){
                System.out.println(temp);
                temp = br.readLine();
                
            }
            if(temp == null){
                System.out.println("Error, no precurser found");
            } else if (temp.equals(PRECURSE)){
                System.out.println("Righto");
                holder = br.readLine();
                System.out.println(holder);
                
                
            } else {
                System.out.println("Error while reading file");
            } 
        } catch (FileNotFoundException fnf){
            System.out.println("FILENOTFOUND THROWN");
        } catch (IOException ioe){
            System.out.println("IEOXCEPTION THROWN");
        } finally {
            try {
                if(is != null){ is.close();}
            } catch (IOException ioe){
                
            }
        }
        
        
        
    }
    
    public boolean same(RowInfo a, RowInfo b){
        if((a.getDate() == b.getDate()) && (a.getTakenBy() == b.getTakenBy()) && (a.getWho() == b.getWho()) && (a.ifFoundChanged() == b.ifFoundChanged())){ 
            return true;
        } else {
            return false;
        }
    }
}