import java.util.Date;
import java.util.ArrayList;
public class tableInfo{
    private ArrayList<Array> dates;
    
    
}