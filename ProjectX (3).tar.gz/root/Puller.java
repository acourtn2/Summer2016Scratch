import java.net.*;
import java.io.*;
import java.util.Date;
public class Puller{
    private URL url;
    private InputStream is;
    private BufferedReader br;
    private String temp;
    private FileWriter fw;
    private Date cur;
    
    public Puller(){
        
        
    }
    public Date getCurDate(){
        return cur;
        
    }
    public void makeFile(){
        try{
            url = new URL("http://quest.library.illinois.edu/timesheet/publicsub.asp");
            is = url.openStream();
            br = new BufferedReader(new InputStreamReader(is));
            cur = new Date();
            fw = new FileWriter("TestFile" + cur + ".txt");
            temp = br.readLine();
            
            while(temp!= null){
                //System.out.println(temp);
                fw.write(temp + "\n");
                temp = br.readLine();
                fw.flush();
            }
            
        } catch (MalformedURLException mue) {
             mue.printStackTrace();
        } catch (IOException ioe) {
            ioe.printStackTrace();
    } finally {
        try {
            if (is != null) is.close();
        } catch (IOException ioe) {
            // nothing to see here
        }
    }
}
        
    
    
}