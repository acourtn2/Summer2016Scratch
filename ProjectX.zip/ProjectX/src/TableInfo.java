import java.util.Date;
import java.util.ArrayList;
public class TableInfo{
    private ArrayList<ArrayList<RowInfo>> dates;
    
    public TableInfo(){
    	
    }
    
    
}