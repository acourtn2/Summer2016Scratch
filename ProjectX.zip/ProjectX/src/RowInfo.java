import java.util.Date;

public class RowInfo{
    private Date d;
    private boolean foundChanged;
    private String who, takenBy;
    
    public RowInfo(Date d, String who, String takenBy){
        this.d = d;
        this.who = who;
        this.takenBy = takenBy;
    }
    public RowInfo(RowInfo cop){
        this.d = cop.getDate();
        this.who = cop.getWho();
        this.takenBy = cop.getTakenBy();
        
    }
    public Date getDate(){
        return this.d;
    }
    public String getWho(){
        return this.who;
    }
    public String getTakenBy(){
        return this.takenBy;
    }
    public boolean ifFoundChanged(){
        return this.foundChanged;
    }
    
}