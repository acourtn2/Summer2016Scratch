public class ProjectX{
    public static void main(String[] args){
        Puller a = new Puller();
        a.makeFile();
        
        Parser b = new Parser(a.getFilName());
        System.out.println("bug2");
        b.parse();
    }
}