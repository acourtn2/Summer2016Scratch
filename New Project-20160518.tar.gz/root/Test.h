#include <vector>
using namespace std;
class Test{
    public:
        void testFun();
        void addVec(int a);
        void printVec();
    private:
        vector<int> vecy;
};