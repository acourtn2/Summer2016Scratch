#include "Test.h"
#include <iostream>

using namespace std;
void Test::testFun(){
    cout << "Worked" << endl;
    
}
void Test::printVec(){
    for(int i = 0; i < vecy.size(); i++){
        cout << vecy[i] <<endl;
    }
    
}
void Test::addVec(int a){
    vecy.push_back(a);
    
}