#include <iostream>
#include "Test.h"
using namespace std;

int main()
{
   cout << "Hello World" << endl; 
   Test part;
   part.testFun();
   part.addVec(2);
   part.addVec(4);
   part.addVec(3);
   part.printVec();
   return 0;
}

