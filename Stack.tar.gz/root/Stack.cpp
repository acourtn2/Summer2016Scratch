#include "Stack.h"
#include <iostream>

using namespace std;

void Stack::print(){
    for(int i = 0; i < s.size(); i++){
        cout << s[i] << endl;
    }
    
}

void Stack::pop(){
    s.pop_back();
    
}

int Stack::size(){
    return s.size();
    
}

bool Stack::isEmpty(){
    return s.size() == 0;
    
}

void Stack::push(int a){
    s.push_back(a);   
}
