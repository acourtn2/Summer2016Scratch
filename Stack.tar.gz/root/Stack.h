#include <vector>

using namespace std;

//@author:Andrew Courtney
//@date:5/18/16


class Stack{
    public:
        void print();
        void pop();
        int size();
        bool isEmpty();
        void push(int a);
    private:
        vector<int> s;
    
};