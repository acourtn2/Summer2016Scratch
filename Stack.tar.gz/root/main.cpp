#include <iostream>
#include "Stack.h"
using namespace std;

int main()
{
   cout << "Hello World" << endl; 
 
   Stack s;
   for(int i = 0; i < 10; i++){
       s.push(i+1);
   }
   cout << "Size is: " << s.size() << endl;
   cout << "Is empty" << s.isEmpty() << endl;
   while(!s.isEmpty()){
       cout << "emptying stack" << endl;
       s.pop();
       
   }
     cout << "Size is: " << s.size() << endl;
   cout << "Is empty" << s.isEmpty() << endl;
   
   return 0;
}

