import java.util.*;
public class Comparer {
	private TableInfo holder;
	private Date now;
	
	public Comparer(){
		
	}
	
	
	public void compare(int code, /*ArrayList<ArrayList<RowInfo>>*/ TableInfo tableOne, /*ArrayList<ArrayList<RowInfo>>*/ TableInfo tableTwo){
		// code 1: only changes from unavailable/non-existant to open
		// code 2: changes from non-existant to open
		// code 3: all changes
		now = new Date();
		now.setTime(0);
		holder = new TableInfo(1, new Date());
		if(code == 1){
			compare1(tableOne, tableTwo);
		} else if( code == 2){
			
		} else if (code == 3){
			
		} else {
			System.out.println("Compare error, defualt used");
			
		}
		
	}
	
	private void compare1(/*ArrayList<ArrayList<RowInfo>>*/ TableInfo tableOne, /*ArrayList<ArrayList<RowInfo>>*/ TableInfo tableTwo){
		for(int i = 1; i < tableOne.getDates().size(); i++){ // skips i = 0, as is a base holder;
			for(int j = 0; j < tableOne.getDates().get(i).size(); j++){
				if(now.compareTo(tableOne.getDates().get(i).get(0).getDate()) <= 0){
				//	System.out.println(tableOne.get(i).get(j));
					holder.addRowInfo(tableOne.getDates().get(i).get(j));
				}
			}
		}
		//holder.printTable();
		for(int i = 1; i < tableTwo.getDates().size(); i++){
			for(int j = 0; j < tableTwo.getDates().get(i).size(); j++){
				if(now.compareTo(tableTwo.getDates().get(i).get(0).getDate()) <= 0){
					RowInfo temp = tableTwo.getDates().get(i).get(j);
					
					int dateIndex = holder.getDateIndex(temp.getDate());
					if(dateIndex == -1){
						holder.addRowInfo(temp);
						//added shift with new date
					} else {
						ArrayList<RowInfo> section = holder.getDates().get(dateIndex);
						boolean found = false;
						for(int k = 0; k < section.size(); k++){
							if(section.get(k).isSame(temp)){
								//System.out.println("got Here");
								holder.getDates().get(dateIndex).remove(k);
								if(holder.getDates().get(dateIndex).size() == 0){
									holder.getDates().remove(dateIndex);		
								}
								found = true;
								break;
							}
						}
						if(!found){
						//	System.out.println("BUgged4");
							holder.addRowInfo(temp);// existing Date,added shift
						}
					}
				}
			}
		}
		holder.printTable();
		compareHelper(holder);
		
	}
	
	private void compare2(ArrayList<ArrayList<RowInfo>> tableOne, ArrayList<ArrayList<RowInfo>> tableTwo){
		
	
	}
	
	private void compare3(ArrayList<ArrayList<RowInfo>> tableOne, ArrayList<ArrayList<RowInfo>> tableTwo){
		
		
	}
	
	private void compareHelper(TableInfo inTI){
		TableInfo temp = new TableInfo(1, inTI.getDateMade());
		for(int i = 0 ; i < inTI.getDates().size(); i++){
			for(int j = 0; j < inTI.getDates().get(i).size();j++){
				boolean foundEqual = false;
				RowInfo a = inTI.getDates().get(i).get(j); // check a, not b
				for(int k = 0 ; k < inTI.getDates().get(i).size(); k++){
					if(j!=k){
						RowInfo b = inTI.getDates().get(i).get(k);
						if(a.isSameShift(b)){
							foundEqual = true;
							if(a.getDateMade().compareTo(b.getDateMade()) == 0){
								System.out.println("Same Rowinfo and dates made for two different tables, check system");
							} else if(a.getDateMade().compareTo(b.getDateMade()) <= 0){
								
							}else if(a.getDateMade().compareTo(b.getDateMade()) >= 0){
								if(a.getTakenBy().equals("Sub Needed")){
									temp.addRowInfo(a);
									
								}
							} else {
								System.out.println("CompareHelper Error");
							}
							break;
						}
					}
				}
				if(!foundEqual){
					if(a.getTakenBy().equals("Sub Needed")){
						temp.addRowInfo(a);
						
					}
				}
			}
		}
		System.out.println("compared and reduced table --------------------------------------");
		temp.printTable();
		
	}
	
}
