import java.util.Date;

public class RowInfo{
    private Date d, dateMade;
    private boolean foundChanged;
    private String who, takenBy;
    private int time;
    
    public RowInfo(Date d, String who, String takenBy, int time, Date dateMade){
        this.d = d;
        this.who = who;
        this.takenBy = takenBy;
        this.time = time;
        this.dateMade = dateMade;
    }
    public RowInfo(RowInfo cop){
        this.d = cop.getDate();
        this.who = cop.getWho();
        this.takenBy = cop.getTakenBy();
        this.time = cop.getTime();
        this.dateMade = cop.getDateMade();
        
    }
    public Date getDateMade(){
    	return this.dateMade;
    }
    public int getTime(){
        return this.time;
    }
    public Date getDate(){
        return this.d;
    }
    public String getWho(){
        return this.who;
    }
    public String getTakenBy(){
        return this.takenBy;
    }
    public boolean ifFoundChanged(){
        return this.foundChanged;
    }
    public boolean isSame(RowInfo a){
    	return ((this.d).compareTo(a.getDate()) == 0 && (this.who).compareTo(a.getWho()) == 0 && (this.takenBy).compareTo(a.getTakenBy()) == 0 && this.time == a.getTime());
    }
    public boolean isSameShift(RowInfo a){
    	return ((this.d).compareTo(a.getDate()) == 0 && (this.who).compareTo(a.getWho()) == 0  && this.time == a.getTime());
    }
    public String toString(){
        return ("Date: " + this.getDate() + "\nWho: " + this.getWho() + "\nTakenBy: " + this.getTakenBy() + "\nTime: " + this.getTime());
    }
    public String toString(int i){
        return ("Date: " + this.getDate() + "\nWho: " + this.getWho() + "\nTakenBy: " + this.getTakenBy() + "\nTime: " + this.getTime() + "\nDateMade:" + this.getDateMade());
    }
}