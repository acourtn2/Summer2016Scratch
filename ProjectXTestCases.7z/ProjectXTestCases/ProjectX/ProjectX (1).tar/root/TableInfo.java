import java.util.Date;
import java.util.ArrayList;
@SuppressWarnings("deprecation")
public class TableInfo{
    private ArrayList<ArrayList<RowInfo>> dates;
    
    public TableInfo(){
    	dates = new ArrayList< ArrayList<RowInfo>>(10) ;
    	RowInfo baseDate = new RowInfo(new Date(0,0,1), "baselinePlaceholder", "Nobody", 0); //1900, Jan, 1
    	dates.add((new ArrayList<RowInfo>(10)));
    	dates.get(0).add(baseDate);
    //	System.out.println(dates.get(0).get(0));
    }
    
    public void addRowInfo(RowInfo ri){
        Date temp, riDate = ri.getDate();
        for(int i = 0 ; i < dates.size(); i++){
            temp = dates.get(i).get(0).getDate();
            if(riDate.compareTo(temp) == 0){
                dates.get(i).add(ri);
                this.fixTimes();
                return;
            }else if(riDate.compareTo(temp) < 0){
                dates.add(i,new ArrayList<RowInfo>(10));
                dates.get(i).add(ri);
                this.fixTimes();
                return;
            }else {
                
            }
        }
        //error checking
        if(riDate.compareTo(dates.get(dates.size()-1).get(0).getDate()) >0){
            dates.add(new ArrayList<RowInfo>(10));
            dates.get(dates.size()-1).add(ri);
            this.fixTimes();
            return;
        } else {
            System.out.println("LOGIC ERROR FROM INSERTION OF NEW DATE INTO DATES");
        }
    }
    
    private void fixTimes(){
        for(int i = 0; i < dates.size(); i++){
     //       dates.set(i,(mergeSort(dates.get(i))));
        }
    }
    
    private static ArrayList<RowInfo> mergeSort(ArrayList<RowInfo> a){
        if(a.size() < 2) {
            return a;
        }
        ArrayList<RowInfo> left, right;
        int partitionPoint = (int)Math.floor(a.size()/2);
        
        left = mergeSort(new ArrayList<RowInfo>(a.subList(0,partitionPoint)));
        right = mergeSort(new ArrayList<RowInfo>(a.subList(partitionPoint,a.size())));
        
        return merge(left, right);
    }
    
    private static ArrayList<RowInfo> merge(ArrayList<RowInfo> left, ArrayList<RowInfo> right){
        int leftIter = 0, rightIter = 0;
        ArrayList<RowInfo> holder = new ArrayList<RowInfo>(10);
        while((leftIter < left.size()) && (rightIter < right.size())){
            if(left.get(leftIter).getTime() < right.get(rightIter).getTime()){
                holder.add(left.get(leftIter));
                leftIter++;
            } else if(left.get(leftIter).getTime() > right.get(rightIter).getTime()){
                holder.add(right.get(rightIter));
                rightIter++;
            } else { // both same time, sort my alphanumerical precedent
                if((left.get(leftIter).getWho()).compareTo(right.get(rightIter).getWho()) < 0){
                    holder.add(left.get(leftIter));
                    leftIter++;
                } else if ((left.get(leftIter).getWho()).compareTo(right.get(rightIter).getWho()) > 0){
                    holder.add(right.get(rightIter));
                    rightIter++;
                } else {
                    System.out.println("ERROR, TWO WHOS WITH SAME TIME");
                }
            }
        }
        if(leftIter == left.size()){
            for(int i = rightIter; i < right.size(); i++){
                holder.add(right.get(i));
            }
        } else if(rightIter == right.size()){
            for(int i = leftIter; i < left.size(); i++){
                holder.add(left.get(i));
            }
        } else {
            System.out.println("ERROR MERGE BUG");
            
        }
         return holder;
    }
    
    public void printTable(){
        System.out.println("Printing table...");
        for(int i = 0; i < dates.size(); i++){
            System.out.println("New date subsection\n-----------------------------------------------" );
            for(int j = 0; j < dates.get(i).size(); j++){
                System.out.println(dates.get(i).get(j));
            }
        }
        
    }
   // public 
    
}